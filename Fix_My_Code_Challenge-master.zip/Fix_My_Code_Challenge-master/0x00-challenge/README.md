# Fix-my-code-0
Fix my code is a new type of project, where we’ll jump into an existing code base and fix it!
