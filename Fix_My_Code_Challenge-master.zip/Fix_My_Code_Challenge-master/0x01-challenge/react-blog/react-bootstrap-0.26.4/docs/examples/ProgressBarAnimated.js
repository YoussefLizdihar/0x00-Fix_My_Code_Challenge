const progressInstance = (
  <ProgressBar active now={45} />
);

React.render(progressInstance, mountNode);
